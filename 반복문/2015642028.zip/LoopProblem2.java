package �ݺ���;

public class LoopProblem2 {

	public static void main(String[] args) {
		int multi=1;
		
		for(int i=1; i<=10; i++){
			multi *= i;
		}
		System.out.println(multi);
	}

}
