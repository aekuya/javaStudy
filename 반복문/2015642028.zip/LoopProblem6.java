package �ݺ���;

public class LoopProblem6 {

	public static void main(String[] args) {
		int min =3;
		int i=min;
		
		for(int count=0; count<5; count++){
			System.out.print(2*i-1+" ");
			i++;
		}

	}
}
